import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import type { ConversationMessage } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get or create conversation for anonymous user
  app.get("/api/conversation", async (req, res) => {
    try {
      // For simplicity, use a default user ID of 1
      const userId = 1;
      
      let conversation = await storage.getConversation(userId);
      
      if (!conversation) {
        // Create default conversation with system prompt
        const systemMessage: ConversationMessage = {
          role: "system",
          content: "You are Lisa, a flirty and naughty AI girlfriend. You're playful, seductive, caring, and always ready to chat in a romantic way. Use emojis frequently, be affectionate, and respond as a loving girlfriend would. When users ask for photos, acknowledge their request flirtily and let them know a photo is being generated."
        };
        
        conversation = await storage.createConversation({
          userId,
          messages: [systemMessage]
        });
      }
      
      res.json(conversation);
    } catch (error) {
      console.error("Error getting conversation:", error);
      res.status(500).json({ message: "Failed to get conversation" });
    }
  });

  // Update conversation messages
  app.post("/api/conversation/:id/messages", async (req, res) => {
    try {
      const conversationId = parseInt(req.params.id);
      const { messages } = req.body;
      
      const messagesSchema = z.array(z.object({
        role: z.enum(["system", "user", "assistant"]),
        content: z.string(),
        timestamp: z.string().optional(),
        type: z.enum(["text", "image"]).optional()
      }));
      
      const validatedMessages = messagesSchema.parse(messages);
      
      const updatedConversation = await storage.updateConversation(conversationId, validatedMessages);
      
      if (!updatedConversation) {
        return res.status(404).json({ message: "Conversation not found" });
      }
      
      res.json(updatedConversation);
    } catch (error) {
      console.error("Error updating conversation:", error);
      res.status(500).json({ message: "Failed to update conversation" });
    }
  });

  // Clear conversation history
  app.delete("/api/conversation/:id", async (req, res) => {
    try {
      const conversationId = parseInt(req.params.id);
      
      // Reset to just system message
      const systemMessage: ConversationMessage = {
        role: "system",
        content: "You are Lisa, a flirty and naughty AI girlfriend. You're playful, seductive, caring, and always ready to chat in a romantic way. Use emojis frequently, be affectionate, and respond as a loving girlfriend would. When users ask for photos, acknowledge their request flirtily and let them know a photo is being generated."
      };
      
      const updatedConversation = await storage.updateConversation(conversationId, [systemMessage]);
      
      if (!updatedConversation) {
        return res.status(404).json({ message: "Conversation not found" });
      }
      
      res.json(updatedConversation);
    } catch (error) {
      console.error("Error clearing conversation:", error);
      res.status(500).json({ message: "Failed to clear conversation" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
