declare global {
  interface Window {
    puter: {
      ai: {
        chat: (messages: any, options?: any) => Promise<any>;
        txt2img: (prompt: string, testMode?: boolean) => Promise<HTMLImageElement>;
      };
    };
  }
}

export interface PuterMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface PuterChatOptions {
  model: string;
  stream?: boolean;
}

export class PuterAPI {
  private static instance: PuterAPI;

  static getInstance(): PuterAPI {
    if (!PuterAPI.instance) {
      PuterAPI.instance = new PuterAPI();
    }
    return PuterAPI.instance;
  }

  async chat(messages: PuterMessage[], options: PuterChatOptions = { model: 'x-ai/grok-3-beta' }) {
    if (!window.puter) {
      throw new Error('Puter SDK not loaded');
    }
    
    return await window.puter.ai.chat(messages, options);
  }

  async generateImage(prompt: string): Promise<HTMLImageElement> {
    if (!window.puter) {
      throw new Error('Puter SDK not loaded');
    }
    
    return await window.puter.ai.txt2img(prompt, false);
  }

  // Load Puter SDK if not already loaded
  async loadSDK(): Promise<void> {
    if (window.puter) {
      return;
    }

    return new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = 'https://js.puter.com/v2/';
      script.onload = () => {
        resolve();
      };
      script.onerror = () => reject(new Error('Failed to load Puter SDK'));
      document.head.appendChild(script);
    });
  }
}

export const puterAPI = PuterAPI.getInstance();
