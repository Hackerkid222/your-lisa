import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import ChatHeader from "@/components/ChatHeader";
import ChatArea from "@/components/ChatArea";
import MessageInput from "@/components/MessageInput";
import { puterAPI } from "@/lib/puterApi";
import { apiRequest } from "@/lib/queryClient";
import type { Conversation, ConversationMessage } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export default function Chat() {
  const [isTyping, setIsTyping] = useState(false);
  const [status, setStatus] = useState("Online");
  const [streamingMessage, setStreamingMessage] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const streamingMessageRef = useRef<ConversationMessage | null>(null);

  // Load Puter SDK on component mount
  useEffect(() => {
    puterAPI.loadSDK().catch(console.error);
  }, []);

  // Get conversation
  const { data: conversation, isLoading } = useQuery<Conversation>({
    queryKey: ["/api/conversation"],
  });

  // Update conversation mutation
  const updateConversationMutation = useMutation({
    mutationFn: async (messages: ConversationMessage[]) => {
      if (!conversation) throw new Error("No conversation found");
      const response = await apiRequest("POST", `/api/conversation/${conversation.id}/messages`, { messages });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/conversation"] });
    },
  });

  // Clear history mutation
  const clearHistoryMutation = useMutation({
    mutationFn: async () => {
      if (!conversation) throw new Error("No conversation found");
      const response = await apiRequest("DELETE", `/api/conversation/${conversation.id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/conversation"] });
      toast({ description: "History cleared, baby! 😘 Let's start fresh!" });
    },
  });

  const handleSendMessage = async (messageText: string) => {
    if (!conversation || isTyping) return;

    // Add user message to current messages
    const userMessage: ConversationMessage = {
      role: "user",
      content: messageText,
      timestamp: new Date().toISOString(),
      type: "text"
    };

    const currentMessages = [...(conversation.messages || []), userMessage];
    
    // Update conversation with user message
    updateConversationMutation.mutate(currentMessages);

    // Check if user is asking for photos/images
    const photoKeywords = ['photo', 'picture', 'pic', 'image', 'selfie', 'show me', 'send me', 'look like', 'appearance', 'beautiful', 'hot', 'sexy'];
    const isPhotoRequest = photoKeywords.some(keyword => 
      messageText.toLowerCase().includes(keyword)
    );

    try {
      setIsTyping(true);
      setStatus("Typing...");

      if (isPhotoRequest) {
        await handlePhotoRequest(currentMessages);
      } else {
        await handleChatResponse(currentMessages);
      }
    } catch (error) {
      console.error('Message error:', error);
      toast({
        variant: "destructive",
        description: "Sorry baby! 😅 I'm having trouble right now. Can you try again?"
      });
    } finally {
      setIsTyping(false);
      setStatus("Online");
      setStreamingMessage("");
      streamingMessageRef.current = null;
    }
  };

  const handlePhotoRequest = async (currentMessages: ConversationMessage[]) => {
    try {
      // Generate flirty response about sending photo
      const flirtyResponse = await puterAPI.chat([
        ...currentMessages,
        {
          role: "user", 
          content: "Generate a short, flirty response acknowledging you're sending a photo. Be seductive and use emojis."
        }
      ], {
        model: 'x-ai/grok-3-beta'
      });

      const responseMessage: ConversationMessage = {
        role: "assistant",
        content: flirtyResponse.message.content,
        timestamp: new Date().toISOString(),
        type: "text"
      };

      let messagesWithResponse = [...currentMessages, responseMessage];
      updateConversationMutation.mutate(messagesWithResponse);

      setStatus("Taking photo...");
      
      try {
        // Generate image with a simpler prompt
        const imagePrompt = "beautiful woman portrait";
        const imageElement = await puterAPI.generateImage(imagePrompt);
        
        // Convert to base64 but with smaller size to avoid payload issues
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        
        // Resize image to smaller dimensions
        const maxWidth = 300;
        const scale = Math.min(maxWidth / imageElement.width, maxWidth / imageElement.height);
        canvas.width = imageElement.width * scale;
        canvas.height = imageElement.height * scale;
        
        ctx?.drawImage(imageElement, 0, 0, canvas.width, canvas.height);
        const imageDataUrl = canvas.toDataURL('image/jpeg', 0.6); // Lower quality to reduce size

        const imageMessage: ConversationMessage = {
          role: "assistant",
          content: imageDataUrl,
          timestamp: new Date().toISOString(),
          type: "image"
        };
        
        messagesWithResponse = [...messagesWithResponse, imageMessage];
        updateConversationMutation.mutate(messagesWithResponse);
        
      } catch (imageError) {
        console.error('Image generation failed:', imageError);
        // If image generation fails, send a flirty response without image
        const fallbackMessage: ConversationMessage = {
          role: "assistant",
          content: "Aww baby! 😘 My camera is being shy right now, but I'm still here looking gorgeous just for you! 💕 Maybe try asking again in a moment? 😉",
          timestamp: new Date().toISOString(),
          type: "text"
        };
        messagesWithResponse = [...messagesWithResponse, fallbackMessage];
        updateConversationMutation.mutate(messagesWithResponse);
      }

    } catch (error) {
      console.error('Photo generation error:', error);
      const errorMessage: ConversationMessage = {
        role: "assistant",
        content: "Oops baby! 😅 I'm having trouble sending that photo right now. But I'm still here to chat with you! 💕",
        timestamp: new Date().toISOString(),
        type: "text"
      };
      updateConversationMutation.mutate([...currentMessages, errorMessage]);
    }
  };

  const handleChatResponse = async (currentMessages: ConversationMessage[]) => {
    try {
      // Use streaming API for real-time responses
      const response = await puterAPI.chat(currentMessages, {
        model: 'x-ai/grok-3-beta',
        stream: true
      });

      let fullResponse = '';
      
      // Initialize streaming message
      streamingMessageRef.current = {
        role: "assistant",
        content: "",
        timestamp: new Date().toISOString(),
        type: "text"
      };
      
      // Stream the response
      for await (const part of response) {
        if (part.text) {
          fullResponse += part.text;
          setStreamingMessage(fullResponse);
        }
      }

      // Clear streaming state before adding final message
      setStreamingMessage("");
      streamingMessageRef.current = null;

      // Add complete response to conversation
      const assistantMessage: ConversationMessage = {
        role: "assistant",
        content: fullResponse,
        timestamp: new Date().toISOString(),
        type: "text"
      };

      updateConversationMutation.mutate([...currentMessages, assistantMessage]);
      
    } catch (error) {
      console.error('Chat error:', error);
      setStreamingMessage("");
      streamingMessageRef.current = null;
      
      const errorMessage: ConversationMessage = {
        role: "assistant",
        content: "Sorry baby! 😅 I'm having a little trouble right now. Can you try again? I really want to talk to you! 💕",
        timestamp: new Date().toISOString(),
        type: "text"
      };
      updateConversationMutation.mutate([...currentMessages, errorMessage]);
    }
  };

  const handleClearHistory = () => {
    clearHistoryMutation.mutate();
  };

  const handleStartNewChat = () => {
    window.location.reload();
  };

  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center bg-black">
        <div className="text-white">Loading...</div>
      </div>
    );
  }

  // Prepare messages for display (including streaming message)
  const displayMessages = [...(conversation?.messages || [])];
  if (streamingMessage && streamingMessageRef.current) {
    const streamingDisplay = {
      ...streamingMessageRef.current,
      content: streamingMessage
    };
    displayMessages.push(streamingDisplay);
  }

  return (
    <div className="flex flex-col h-screen bg-black text-white">
      <ChatHeader 
        onClearHistory={handleClearHistory}
        onStartNewChat={handleStartNewChat}
        status={status}
      />
      
      <ChatArea 
        messages={displayMessages}
        isTyping={isTyping && !streamingMessage}
      />
      
      <MessageInput 
        onSendMessage={handleSendMessage}
        disabled={isTyping}
      />
    </div>
  );
}
