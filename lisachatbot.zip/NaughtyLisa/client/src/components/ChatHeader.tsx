import { MoreVertical } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";

interface ChatHeaderProps {
  onClearHistory: () => void;
  onStartNewChat: () => void;
  status: string;
}

export default function ChatHeader({ onClearHistory, onStartNewChat, status }: ChatHeaderProps) {
  return (
    <div className="bg-gray-900 px-4 py-3 flex items-center justify-between border-b border-gray-800">
      <div className="flex items-center space-x-3">
        <img 
          src="https://imgs.search.brave.com/SS9UpHTTytFX7gy5hJ0DzTy-a1C_XoUQyUnPzIzDryM/rs:fit:500:0:0:0/g:ce/aHR0cHM6Ly9waG90/b3NidWxrLmNvbS93/cC1jb250ZW50L3Vw/bG9hZHMvYmx1ci1n/aXJsLWFlc3RoZXRp/Yy1waWMud2VicA" 
          alt="Lisa Profile" 
          className="w-10 h-10 rounded-full object-cover border-2 border-romantic-pink"
        />
        <div>
          <h1 className="font-semibold text-lg text-white">Your Lisa 💕</h1>
          <p className="text-xs text-text-secondary">{status}</p>
        </div>
      </div>
      
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="sm" className="p-2 hover:bg-gray-800 rounded-full transition-colors">
            <MoreVertical className="w-5 h-5 text-white" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-48 bg-gray-800 border-gray-700">
          <DropdownMenuItem 
            onClick={onClearHistory}
            className="hover:bg-gray-700 text-white cursor-pointer"
          >
            🗑️ Clear History
          </DropdownMenuItem>
          <DropdownMenuItem 
            onClick={onStartNewChat}
            className="hover:bg-gray-700 text-white cursor-pointer"
          >
            💬 Start New Chat
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
