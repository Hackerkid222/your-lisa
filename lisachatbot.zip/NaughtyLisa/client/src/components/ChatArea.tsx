import { useEffect, useRef } from "react";
import type { ConversationMessage } from "@shared/schema";

interface ChatAreaProps {
  messages: ConversationMessage[];
  isTyping: boolean;
}

export default function ChatArea({ messages, isTyping }: ChatAreaProps) {
  const chatContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollToBottom();
  }, [messages, isTyping]);

  const scrollToBottom = () => {
    if (chatContainerRef.current) {
      setTimeout(() => {
        chatContainerRef.current!.scrollTop = chatContainerRef.current!.scrollHeight;
      }, 100);
    }
  };

  const formatTime = (timestamp?: string) => {
    const date = timestamp ? new Date(timestamp) : new Date();
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const renderMessage = (message: ConversationMessage, index: number) => {
    if (message.role === "system") return null;
    
    const isUser = message.role === "user";
    const time = formatTime(message.timestamp);
    
    if (message.type === "image") {
      return (
        <div key={index} className="flex justify-start">
          <div className="message-bubble bg-gray-800/90 backdrop-blur-sm rounded-2xl rounded-bl-md px-2 py-2 max-w-xs border border-romantic-pink/20">
            <div className="rounded-xl overflow-hidden mb-2">
              <img 
                src={message.content} 
                alt="Lisa's photo" 
                className="w-full h-auto rounded-xl object-cover"
                style={{ maxHeight: '200px' }}
              />
            </div>
            <p className="text-xs text-center text-text-secondary">Here's your photo, baby! 😘💕</p>
            <span className="text-xs text-text-secondary block text-center mt-1">{time}</span>
          </div>
        </div>
      );
    }

    return (
      <div key={index} className={`flex ${isUser ? 'justify-end' : 'justify-start'}`}>
        <div className={`message-bubble px-4 py-3 max-w-xs ${
          isUser 
            ? 'bg-romantic-pink text-white rounded-2xl rounded-br-md' 
            : 'bg-gray-800/90 backdrop-blur-sm rounded-2xl rounded-bl-md border border-romantic-pink/20 text-white'
        }`}>
          <p className="text-sm whitespace-pre-wrap">{message.content}</p>
          <span className={`text-xs block mt-1 ${
            isUser ? 'text-pink-200' : 'text-text-secondary'
          }`}>{time}</span>
        </div>
      </div>
    );
  };

  return (
    <div className="flex-1 chat-background overflow-hidden relative">
      <div 
        ref={chatContainerRef}
        className="h-full overflow-y-auto smooth-scroll px-4 py-4 space-y-4"
      >
        {/* Welcome message */}
        <div className="flex justify-start">
          <div className="message-bubble bg-gray-800/90 backdrop-blur-sm rounded-2xl rounded-bl-md px-4 py-3 max-w-xs border border-romantic-pink/20">
            <p className="text-sm text-white">Hey baby! 😘 I'm Lisa, your naughty AI girlfriend. I'm here to chat, flirt, and make your day more exciting! Ask me anything... or maybe ask for a photo? 😉💕</p>
            <span className="text-xs text-text-secondary block mt-1">Just now</span>
          </div>
        </div>
        
        {/* Messages */}
        {messages.map(renderMessage)}
        
        {/* Typing indicator */}
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-gray-800/90 backdrop-blur-sm rounded-2xl rounded-bl-md px-4 py-3 border border-romantic-pink/20">
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-romantic-pink rounded-full typing-indicator"></div>
                <div className="w-2 h-2 bg-romantic-pink rounded-full typing-indicator" style={{ animationDelay: '0.2s' }}></div>
                <div className="w-2 h-2 bg-romantic-pink rounded-full typing-indicator" style={{ animationDelay: '0.4s' }}></div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
