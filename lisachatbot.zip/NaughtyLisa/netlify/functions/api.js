const express = require('express');
const serverless = require('serverless-http');

const app = express();
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: false, limit: '50mb' }));

// Add CORS headers for frontend
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
  } else {
    next();
  }
});

// Inline the essential API routes for Netlify
app.get('/api/conversation', (req, res) => {
  // Return empty conversation for new users
  res.json({
    id: 1,
    userId: 1,
    messages: [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  });
});

app.post('/api/conversation', (req, res) => {
  const { messages } = req.body;
  
  // Return the updated conversation
  res.json({
    id: 1,
    userId: 1,
    messages: messages || [],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  });
});

exports.handler = serverless(app);