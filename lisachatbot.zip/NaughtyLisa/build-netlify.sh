#!/bin/bash
echo "Building for Netlify deployment..."

# Build the frontend
npm run build

# Copy headers file to dist
cp _headers dist/

echo "Build complete! Ready for Netlify deployment."